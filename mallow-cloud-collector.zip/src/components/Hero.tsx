import React, { useState } from 'react';
import { MallowCharacter } from './MallowCharacter';
import { Sparkles, Feather, CloudRain, Compass, Heart, Star, Cloud } from 'lucide-react';
import { soundFx } from '../utils/soundFx';

export const Hero: React.FC = () => {
  const [selectedMood, setSelectedMood] = useState<'happy' | 'sleepy' | 'dreamy' | 'giggling'>('happy');

  const moods = [
    { id: 'happy', label: '😊 Happy', desc: 'Bright & bouncy', note: 0 },
    { id: 'sleepy', label: '😴 Sleepy', desc: 'Soft & yawning', note: -2 },
    { id: 'dreamy', label: '⭐ Dreamy', desc: 'Starry gaze', note: 4 },
    { id: 'giggling', label: '🥰 Giggling', desc: 'Joyful chuckles', note: 7 },
  ];

  const handleMoodSelect = (moodId: 'happy' | 'sleepy' | 'dreamy' | 'giggling', note: number) => {
    setSelectedMood(moodId);
    soundFx.playPluck(note);
  };

  return (
    <section id="hero" className="relative pt-28 pb-16 sm:pt-36 sm:pb-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto flex flex-col items-center text-center">
        {/* Hackathon Badge Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/85 dark:bg-purple-950/75 border border-purple-200/80 dark:border-purple-800/80 shadow-sm backdrop-blur-md mb-6 animate-float-bob">
          <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-300" />
          <span className="text-xs sm:text-sm font-bold text-purple-900 dark:text-purple-200">
            Baby's First Website Hackathon Project
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-pink-400" />
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">Sky Playground</span>
        </div>

        {/* Hero Title with preschool magical warmth */}
        <h1 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-slate-800 dark:text-white max-w-3xl leading-tight sm:leading-tight">
          Hello! I'm{' '}
          <span className="bg-gradient-to-r from-sky-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            Mallow
          </span>
          , the Cloud Collector
        </h1>

        {/* Subtitle / Tagline */}
        <p className="mt-4 sm:mt-5 text-base sm:text-xl text-slate-600 dark:text-slate-300 max-w-2xl font-normal leading-relaxed">
          Drifting through the living sky, catching stray daytime wishes, and softening forgotten dreams into
          magical bedtime experiences.
        </p>

        {/* Mallow Character Centerpiece with Interactive Eyes & Physics */}
        <div className="relative my-8 sm:my-10 flex flex-col items-center">
          {/* Gentle glow aura behind character */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 sm:w-96 sm:h-96 rounded-full bg-gradient-to-tr from-pink-200/40 via-purple-200/30 to-sky-200/40 blur-3xl -z-10 pointer-events-none" />

          {/* Character with animated gentle float */}
          <div className="animate-float-gentle">
            <MallowCharacter size="hero" mood={selectedMood} interactive={true} />
          </div>

          <p className="mt-2 text-xs text-slate-500 dark:text-slate-400 font-medium italic">
            ✦ Move your mouse to see Mallow's eyes follow you! Tap to tickle! ✦
          </p>

          {/* Mood Selector Buttons */}
          <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5 sm:gap-2 p-1.5 rounded-2xl bg-white/70 dark:bg-slate-800/70 backdrop-blur-md border border-white/80 dark:border-purple-800/60 shadow-sm">
            <span className="text-xs font-bold px-2 text-slate-500 dark:text-slate-400 hidden sm:inline">
              Mallow's Expression:
            </span>
            {moods.map((m) => (
              <button
                key={m.id}
                onClick={() => handleMoodSelect(m.id as any, m.note)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all toy-button ${
                  selectedMood === m.id
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-sm scale-105'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-white/80 dark:hover:bg-slate-700/70'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 mt-2">
          <a
            href="#pillows"
            onClick={() => soundFx.playChime(523.25)}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-500 via-pink-500 to-indigo-500 text-white font-bold text-sm sm:text-base shadow-md hover:shadow-lg toy-button focus:outline-none focus:ring-2 focus:ring-purple-400"
          >
            <Feather className="w-4 h-4" />
            Let's Fluff a Pillow!
          </a>

          <a
            href="#sound-machine"
            onClick={() => soundFx.playChime(659.25)}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-white/85 dark:bg-slate-800/85 hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-purple-200 font-bold text-sm sm:text-base border border-purple-200/70 dark:border-purple-800/70 shadow-sm toy-button"
          >
            <CloudRain className="w-4 h-4 text-sky-500" />
            Rain Sensory Room
          </a>

          <a
            href="#forecast"
            onClick={() => soundFx.playChime(783.99)}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-white/85 dark:bg-slate-800/85 hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-purple-200 font-bold text-sm sm:text-base border border-purple-200/70 dark:border-purple-800/70 shadow-sm toy-button"
          >
            <Compass className="w-4 h-4 text-pink-500" />
            Tonight's Dream Reveal
          </a>
        </div>
      </div>
    </section>
  );
};
