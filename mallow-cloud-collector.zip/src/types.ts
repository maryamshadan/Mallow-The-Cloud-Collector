export type ThemeMode = 'day' | 'sunset' | 'night';

export interface DreamPillow {
  id: string;
  name: string;
  density: string;
  theme: string;
  fabric: string;
  softness: number;
  fragrance: string;
  createdAt: string;
  color: string;
  essenceIcon?: string;
}

export interface DreamForecast {
  id: string;
  title: string;
  description: string;
  probability: string;
  cloudCover: string;
  temperature: string;
  windSpeed: string;
  recommendedActivity: string;
  luckyToken: string;
  accentColor: string;
  iconName: string;
}

export type RainPreset = 'gentle' | 'window' | 'downpour' | 'mist';
