import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { MallowMood } from '../types';
import { MallowCharacter } from './MallowCharacter';
import { soundFx } from '../utils/soundFx';
import { Sparkles, RefreshCw } from 'lucide-react';

interface Mallow3DProps {
  mood?: MallowMood;
  interactive?: boolean;
  className?: string;
  onTickle?: () => void;
}

export const Mallow3D: React.FC<Mallow3DProps> = ({
  mood = 'happy',
  interactive = true,
  className = '',
  onTickle,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [webglSupported, setWebglSupported] = useState<boolean>(true);
  const [use2DFallback, setUse2DFallback] = useState<boolean>(false);
  const [speechBubble, setSpeechBubble] = useState<string | null>(null);

  // References for animation loop
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const mallowGroupRef = useRef<THREE.Group | null>(null);
  const starMeshRef = useRef<THREE.Mesh | null>(null);
  const eyesGroupRef = useRef<THREE.Group | null>(null);
  const leftEyeRef = useRef<THREE.Mesh | null>(null);
  const rightEyeRef = useRef<THREE.Mesh | null>(null);

  const targetRotationRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const bounceScaleRef = useRef<{ x: number; y: number; z: number }>({ x: 1, y: 1, z: 1 });
  const isVisibleRef = useRef<boolean>(true);
  const animFrameIdRef = useRef<number | null>(null);

  // Check WebGL availability
  useEffect(() => {
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (!gl) {
        setWebglSupported(false);
      }
    } catch {
      setWebglSupported(false);
    }
  }, []);

  useEffect(() => {
    if (!webglSupported || use2DFallback) return;
    const container = mountRef.current;
    if (!container) return;

    // Dimensions
    const width = container.clientWidth || 360;
    const height = container.clientHeight || 340;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0, 5.5);

    // Renderer
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: true,
        powerPreference: 'high-performance',
      });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.1;
      container.appendChild(renderer.domElement);
      rendererRef.current = renderer;
    } catch (e) {
      console.warn('WebGL init failed:', e);
      setWebglSupported(false);
      return;
    }

    // Lights
    const ambientLight = new THREE.AmbientLight(0xfff7ed, 1.2); // Warm gentle ambient
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.4);
    dirLight.position.set(3, 4, 4);
    scene.add(dirLight);

    // Lavender/Blue Rim Light for magical atmosphere
    const rimLight = new THREE.DirectionalLight(0xc084fc, 1.6);
    rimLight.position.set(-3, -2, -2);
    scene.add(rimLight);

    // Peach glow from bottom-left
    const warmLight = new THREE.PointLight(0xfdba74, 1.2, 10);
    warmLight.position.set(2, -2, 2);
    scene.add(warmLight);

    // --- Procedural 3D Mallow Cloud Geometry ---
    const mallowGroup = new THREE.Group();
    scene.add(mallowGroup);
    mallowGroupRef.current = mallowGroup;

    // Materials
    const cloudMat = new THREE.MeshStandardMaterial({
      color: 0xfffefb,
      roughness: 0.75,
      metalness: 0.04,
    });

    const cheekMat = new THREE.MeshBasicMaterial({
      color: 0xf472b6,
      transparent: true,
      opacity: 0.75,
    });

    const eyeMat = new THREE.MeshStandardMaterial({
      color: 0x1e1b4b,
      roughness: 0.1,
      metalness: 0.3,
    });

    const eyeSparkleMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
    });

    const mouthMat = new THREE.MeshBasicMaterial({
      color: 0xe11d48,
    });

    const starMat = new THREE.MeshStandardMaterial({
      color: 0xfde047,
      roughness: 0.2,
      metalness: 0.5,
      emissive: 0xfacc15,
      emissiveIntensity: 0.5,
    });

    // Cloud puffs (cumulus body)
    const puffPositions: [number, number, number, number][] = [
      [0, 0, 0, 1.1], // Center main body
      [-0.75, 0.1, 0, 0.85], // Left puff
      [0.75, 0.1, 0, 0.85], // Right puff
      [-0.45, 0.65, 0, 0.75], // Top-left puff
      [0.45, 0.65, 0, 0.75], // Top-right puff
      [0, 0.8, -0.1, 0.7], // Top-center crown
      [-0.6, -0.4, 0.1, 0.65], // Bottom-left foot
      [0.6, -0.4, 0.1, 0.65], // Bottom-right foot
      [0, -0.45, 0.15, 0.6], // Bottom-center tummy
    ];

    puffPositions.forEach(([x, y, z, radius]) => {
      const geo = new THREE.SphereGeometry(radius, 24, 20);
      const puff = new THREE.Mesh(geo, cloudMat);
      puff.position.set(x, y, z);
      mallowGroup.add(puff);
    });

    // Eyes Group
    const eyesGroup = new THREE.Group();
    eyesGroup.position.set(0, 0.2, 0.95);
    mallowGroup.add(eyesGroup);
    eyesGroupRef.current = eyesGroup;

    // Left Eye
    const leftEyeGeo = new THREE.SphereGeometry(0.14, 20, 16);
    leftEyeGeo.scale(1, 1.25, 0.6);
    const leftEye = new THREE.Mesh(leftEyeGeo, eyeMat);
    leftEye.position.set(-0.35, 0, 0);
    eyesGroup.add(leftEye);
    leftEyeRef.current = leftEye;

    // Left Eye Sparkle Highlight
    const sparkleGeo = new THREE.SphereGeometry(0.045, 12, 10);
    const leftSparkle = new THREE.Mesh(sparkleGeo, eyeSparkleMat);
    leftSparkle.position.set(-0.32, 0.05, 0.07);
    eyesGroup.add(leftSparkle);

    // Right Eye
    const rightEyeGeo = new THREE.SphereGeometry(0.14, 20, 16);
    rightEyeGeo.scale(1, 1.25, 0.6);
    const rightEye = new THREE.Mesh(rightEyeGeo, eyeMat);
    rightEye.position.set(0.35, 0, 0);
    eyesGroup.add(rightEye);
    rightEyeRef.current = rightEye;

    // Right Eye Sparkle Highlight
    const rightSparkle = new THREE.Mesh(sparkleGeo, eyeSparkleMat);
    rightSparkle.position.set(0.38, 0.05, 0.07);
    eyesGroup.add(rightSparkle);

    // Cheeks
    const cheekGeo = new THREE.SphereGeometry(0.13, 16, 12);
    cheekGeo.scale(1.2, 0.7, 0.3);

    const leftCheek = new THREE.Mesh(cheekGeo, cheekMat);
    leftCheek.position.set(-0.55, -0.12, 0.88);
    leftCheek.rotation.y = -0.2;
    mallowGroup.add(leftCheek);

    const rightCheek = new THREE.Mesh(cheekGeo, cheekMat);
    rightCheek.position.set(0.55, -0.12, 0.88);
    rightCheek.rotation.y = 0.2;
    mallowGroup.add(rightCheek);

    // Smiling Mouth (torus segment)
    const mouthGeo = new THREE.TorusGeometry(0.12, 0.03, 10, 16, Math.PI);
    const mouth = new THREE.Mesh(mouthGeo, mouthMat);
    mouth.position.set(0, -0.12, 1.02);
    mouth.rotation.x = Math.PI; // upside down torus curve = smiling arc
    mouth.rotation.z = Math.PI;
    mallowGroup.add(mouth);

    // Tiny Star Accessory (orbiting or pinned near top-right crown)
    const starShape = new THREE.Shape();
    const outerRadius = 0.22;
    const innerRadius = 0.1;
    const points = 5;
    for (let i = 0; i < points * 2; i++) {
      const radius = i % 2 === 0 ? outerRadius : innerRadius;
      const angle = (i * Math.PI) / points - Math.PI / 2;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      if (i === 0) starShape.moveTo(x, y);
      else starShape.lineTo(x, y);
    }
    starShape.closePath();

    const starExtrude = new THREE.ExtrudeGeometry(starShape, {
      depth: 0.06,
      bevelEnabled: true,
      bevelSegments: 2,
      steps: 1,
      bevelSize: 0.02,
      bevelThickness: 0.02,
    });
    starExtrude.center();
    const starMesh = new THREE.Mesh(starExtrude, starMat);
    starMesh.position.set(0.85, 0.85, 0.3);
    mallowGroup.add(starMesh);
    starMeshRef.current = starMesh;

    // Handle Window Resize
    const handleResize = () => {
      if (!container || !rendererRef.current) return;
      const newW = container.clientWidth || 360;
      const newH = container.clientHeight || 340;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      rendererRef.current.setSize(newW, newH);
    };

    window.addEventListener('resize', handleResize);

    // Pointer tracking
    const handlePointerMove = (e: PointerEvent) => {
      if (!interactive) return;
      const rect = container.getBoundingClientRect();
      const clientX = e.clientX - rect.left;
      const clientY = e.clientY - rect.top;

      const normX = (clientX / rect.width) * 2 - 1;
      const normY = -(clientY / rect.height) * 2 + 1;

      targetRotationRef.current.y = normX * 0.45;
      targetRotationRef.current.x = -normY * 0.3;
    };

    window.addEventListener('pointermove', handlePointerMove);

    // Intersection Observer to stop render loop when off-screen
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          isVisibleRef.current = entry.isIntersecting;
        });
      },
      { threshold: 0.05 }
    );
    observer.observe(container);

    // Visibility change (pause on inactive tab)
    const handleVisibility = () => {
      isVisibleRef.current = !document.hidden;
    };
    document.addEventListener('visibilitychange', handleVisibility);

    // Animation Loop
    let clock = new THREE.Clock();
    let blinkTimer = 0;
    let isBlinking = false;

    const animate = () => {
      animFrameIdRef.current = requestAnimationFrame(animate);

      if (!isVisibleRef.current) return;

      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Gentle Floating Bob
      const bobY = Math.sin(elapsed * 2.2) * 0.12;
      const bobTilt = Math.sin(elapsed * 1.5) * 0.05;

      // Smooth Rotation Lerp toward pointer
      mallowGroup.rotation.y += (targetRotationRef.current.y - mallowGroup.rotation.y) * 0.08;
      mallowGroup.rotation.x += (targetRotationRef.current.x - mallowGroup.rotation.x) * 0.08;
      mallowGroup.rotation.z = bobTilt;
      mallowGroup.position.y = bobY;

      // Springy Bounce Scale Damping
      bounceScaleRef.current.x += (1 - bounceScaleRef.current.x) * 0.1;
      bounceScaleRef.current.y += (1 - bounceScaleRef.current.y) * 0.1;
      bounceScaleRef.current.z += (1 - bounceScaleRef.current.z) * 0.1;
      mallowGroup.scale.set(
        bounceScaleRef.current.x,
        bounceScaleRef.current.y,
        bounceScaleRef.current.z
      );

      // Star Accessory Spin & Orbit
      if (starMeshRef.current) {
        starMeshRef.current.rotation.z += 0.03;
        starMeshRef.current.position.y = 0.85 + Math.sin(elapsed * 3) * 0.06;
      }

      // Blinking Mechanism
      blinkTimer += delta;
      if (blinkTimer > 3.5 && !isBlinking) {
        isBlinking = true;
      }
      if (isBlinking) {
        if (leftEyeRef.current && rightEyeRef.current) {
          leftEyeRef.current.scale.y = 0.1;
          rightEyeRef.current.scale.y = 0.1;
        }
        if (blinkTimer > 3.7) {
          if (leftEyeRef.current && rightEyeRef.current) {
            leftEyeRef.current.scale.y = 1.25;
            rightEyeRef.current.scale.y = 1.25;
          }
          isBlinking = false;
          blinkTimer = 0;
        }
      }

      // Render
      renderer.render(scene, camera);
    };

    animate();

    // Clean up
    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('pointermove', handlePointerMove);
      document.removeEventListener('visibilitychange', handleVisibility);
      observer.disconnect();

      // Dispose Geometries & Materials
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
          if (Array.isArray(obj.material)) {
            obj.material.forEach((m) => m.dispose());
          } else {
            obj.material.dispose();
          }
        }
      });
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [webglSupported, use2DFallback, interactive]);

  // Click / Tap bounce reaction
  const handleCharacterClick = () => {
    soundFx.playPuff();
    // Squash & Stretch Bounce
    bounceScaleRef.current = { x: 1.25, y: 0.78, z: 1.25 };

    const giggles = [
      'Hehe! That tickles! ✨',
      'Fluff and stardust! ☁️',
      'Soft like a marshmallow!',
      'Boing! You caught me! ⭐',
      'Sending you a cozy cloud hug! 💖',
    ];
    setSpeechBubble(giggles[Math.floor(Math.random() * giggles.length)]);
    setTimeout(() => setSpeechBubble(null), 3000);

    onTickle?.();
  };

  // If user chooses 2D or WebGL fails
  if (!webglSupported || use2DFallback) {
    return (
      <div className={`relative flex flex-col items-center ${className}`}>
        <MallowCharacter size="hero" mood={mood} interactive={interactive} />
        <button
          onClick={() => setUse2DFallback(false)}
          className="mt-3 flex items-center gap-1 text-[11px] font-bold text-purple-600 dark:text-purple-300 px-3 py-1 rounded-full bg-purple-50 dark:bg-purple-950/80 border border-purple-200 dark:border-purple-800 toy-button"
        >
          <Sparkles className="w-3 h-3 text-purple-500" />
          <span>Switch to 3D Mallow</span>
        </button>
      </div>
    );
  }

  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      {/* Speech Bubble on click */}
      {speechBubble && (
        <div className="absolute -top-12 z-20 px-4 py-2 rounded-2xl bg-white/95 dark:bg-slate-900/95 text-slate-800 dark:text-purple-100 text-xs sm:text-sm font-bold shadow-xl border border-purple-200 dark:border-purple-700 animate-bounce">
          {speechBubble}
          <div className="absolute left-1/2 -bottom-2 -translate-x-1/2 w-3 h-3 bg-white dark:bg-slate-900 rotate-45 border-r border-b border-purple-200 dark:border-purple-700" />
        </div>
      )}

      {/* 3D WebGL Canvas Container */}
      <div
        ref={mountRef}
        onClick={handleCharacterClick}
        className="w-72 h-72 sm:w-84 sm:h-84 cursor-pointer focus:outline-none transition-transform active:scale-95"
        role="button"
        tabIndex={0}
        aria-label="Interactive 3D Mallow baby cloud character. Click to tickle."
        title="Tap or click to tickle Mallow! Move cursor to look around."
      />

      {/* Style Toggle (3D / 2D) */}
      <div className="flex items-center gap-2 mt-1">
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
          ✦ Interactive WebGL 3D Mallow ✦
        </span>
        <button
          onClick={() => {
            soundFx.playChime(500);
            setUse2DFallback(true);
          }}
          className="text-[10px] font-bold text-purple-500 hover:text-purple-700 dark:text-purple-400 underline"
          title="Switch to lightweight 2D SVG Mallow"
        >
          Switch to 2D
        </button>
      </div>
    </div>
  );
};
